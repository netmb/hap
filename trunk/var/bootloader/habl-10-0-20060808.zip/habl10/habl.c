////////////////////////////////////////////////////////////////////////////////
// Projekt:              Home-Automation Bootloader                           //
// Modul:                Hauptprogramm                                        //
// Version:              1.0 (0)                                              //
////////////////////////////////////////////////////////////////////////////////
// Erstellt am:          24.03.2006                                           //
// Erstellt von:         Holger Heuser                                        //
// Zuletzt ge�ndert am:  08.08.2006                                           //
// Zuletzt ge�ndert von: Holger Heuser                                        //
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// Module einbinden                                                           //
////////////////////////////////////////////////////////////////////////////////

#include <avr/boot.h>
#include <avr/eeprom.h>
#include <avr/interrupt.h>

#include <hagl.h>

#include <hatwi.h>


////////////////////////////////////////////////////////////////////////////////
// Precompiler Konstanten                                                     //
////////////////////////////////////////////////////////////////////////////////

#define BLEEPCfgStartAdr 0x00
#define BLEEPFlashFlagAdr 0x00
#define BLEEPCodeSizeAdr 0x01

#define BLSSFlashed 0xFF
#define BLSSNotFlashed 0x00

#define BLFlashPageSize 128
#define BLStartAddress 0x7800

#define BLEEPROM256WriteAdr 0xA0
#define BLEEPROM256ReadAdr 0xA1
#define BLEEPROM256PageSize 64


////////////////////////////////////////////////////////////////////////////////
// Funktionen                                                                 //
////////////////////////////////////////////////////////////////////////////////

void BLFlash(void) {

  tWord BytesToFlash;
  tWord Adr;
  tWord FlashAdr;
  tByte i;
  tByte j;
  tWord Data;

  eeprom_read_block(&BytesToFlash, (void *)(BLEEPCfgStartAdr + BLEEPCodeSizeAdr), 2);
  if(BytesToFlash <= BLStartAddress) {
    TWIInit(BLEEPROM256PageSize + 1);
    for(Adr = 0; Adr < BLStartAddress; Adr += BLFlashPageSize) {
      boot_page_erase(Adr);
      boot_spm_busy_wait();
    }
    Adr = 0;
    TWIFillBufferAtIndex(0, BLEEPROM256WriteAdr);
    TWIFillBufferAtIndex(1, 0);
    TWIFillBufferAtIndex(2, 0);
    TWISuppressStopSignal();
    sei();
    TWIStartNormal(3);
    while(TWIBusy());
    while(Adr < BytesToFlash) {
      FlashAdr = Adr;
      for(i = 0; i < 2; i++) {
        sei();
        TWIFillBufferAtIndex(0, BLEEPROM256ReadAdr);
        TWIStartNormal(BLEEPROM256PageSize + 1);
        while(TWIBusy());
        cli();
        for(j = 1; j < BLEEPROM256PageSize; j += 2) {
          Data = TWIGetDataFromIndex(j);
          Data |= TWIGetDataFromIndex(j + 1) << 8;
          boot_page_fill(Adr, Data);
          Adr += 2;
        }
      }
      boot_page_write(FlashAdr);
      boot_spm_busy_wait();
    }
    cli();
    TWIDestroy();
    eeprom_write_byte((void *)(BLEEPCfgStartAdr + BLEEPFlashFlagAdr), BLSSFlashed);
    eeprom_busy_wait();
    boot_rww_enable();
  }
}


////////////////////////////////////////////////////////////////////////////////
// Hauptprogramm                                                              //
////////////////////////////////////////////////////////////////////////////////

int main(void) {

  void (*AppPtr)(void) = 0x0000;

  cli();
  GICR = 1 << IVCE;
  GICR = 1 << IVSEL;
  if(eeprom_read_byte((void *)(BLEEPCfgStartAdr + BLEEPFlashFlagAdr)) == BLSSNotFlashed)
    BLFlash();
  GICR = 1 << IVCE;
  GICR = 0;
  AppPtr();
}
